# recuerdame-perfumes
Proyecto desarrollado con fines de aprendizaje y como parte de un portafolio personal. Diseñado para aplicar habilidades en HTML, CSS y JavaScript, enfocado en crear sitios web responsivos y funcionales. Este trabajo refleja prácticas de diseño web profesional y mejora continua.
